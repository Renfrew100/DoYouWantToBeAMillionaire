
package Millionaire;
import java.awt.Color;
import java.util.concurrent.TimeUnit;


public class timer extends javax.swing.JFrame implements Runnable {
    
    public static int timer = 5;
    
    public void run(){
      
            try{
              
                while(true){
                    if(DoYouWantToBeAMillionaire.timerActive){
                        if (timer == 0){                      
                            QuestionScreen.btnClicked = true;
                            QuestionScreen.answerCorrect = false;
                            LoseScreen LoseWindow = new LoseScreen();
                            LoseWindow.setVisible(true);
                            QuestionScreen.CloseScreen=true;
                            break;
                        }
                        else {
                            System.out.println(timer);
                            Thread.sleep(1000);
                            timer -= 1;
                        }
                    }
                    else{
                        break;
                    }
                    
                }
                
            }
            
            catch(Exception e){
            }
          
        }    
    
    

}
