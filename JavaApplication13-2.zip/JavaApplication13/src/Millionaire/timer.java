
package Millionaire;
import static Millionaire.QuestionScreen.timer_end;
import java.awt.Color;
import java.util.concurrent.TimeUnit;


public class timer extends javax.swing.JFrame implements Runnable {
    
    public static int timer = 5;
    public static boolean timer_end = false;
    
    public void run(){    
            try{
                while(true){
                    if(DoYouWantToBeAMillionaire.timerActive){
                        if (timer == 0){     
                            timer_end(true);
                            timer_end = true;
                            QuestionScreen.btnClicked = true;
                            QuestionScreen.answerCorrect = false;
                            break;
                        }
                        else {
                            System.out.println(timer);
                            Thread.sleep(1000);
                            timer -= 1;
                        }
                    }
                    else{
                        break;
                    }  
                }  
            }
            catch(Exception e){
            }
        }    
}
