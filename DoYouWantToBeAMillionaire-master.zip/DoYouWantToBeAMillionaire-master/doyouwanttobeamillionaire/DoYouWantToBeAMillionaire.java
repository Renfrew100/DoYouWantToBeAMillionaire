
package doyouwanttobeamillionaire;


public class DoYouWantToBeAMillionaire {

    public static void main(String[] args) {
    //MainScreen form = new MainScreen();
    //form.setVisible(true);
    //form.setSize(1366,768);
    
    Instructions form1 = new Instructions();
    form1.setVisible(true);
    form1.setSize(1366,768);
    
    
    
     
    }
    
}
