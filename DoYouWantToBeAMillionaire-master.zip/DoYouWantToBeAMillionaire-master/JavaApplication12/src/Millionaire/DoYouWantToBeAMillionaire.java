package Millionaire;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.util.List;
import java.util.Random;

public class DoYouWantToBeAMillionaire {
    
    public static int question;

    public static ArrayList<ArrayList<String>> loadQuestions(){
        int questionNum = 27;
        String fName = "Q&A.txt";
        String line = null;
        ArrayList<ArrayList<String>> questionsMain = new ArrayList<ArrayList<String>>();
        
        try{
            FileReader fileReader = new FileReader(fName);
            BufferedReader bufferedReader = new BufferedReader(fileReader); 
            for (int j=0; j<questionNum;j++){
                questionsMain.add(new ArrayList<String>());
                for (int i=0; i<6;i++){
                    line = bufferedReader.readLine();
                    if (line == null){
                        break;
                    }
                    else {
                        questionsMain.get(j).add(i, line);
                       
                    }
                } 
            }
        }
        catch(FileNotFoundException ex){
            System.out.println("Cannot find file "+ fName + " .");
        }
        catch(IOException ex){
            System.out.println("Unable to open file '" + fName + "'");
        }
        return(questionsMain);
    }
    
    public static int randomQuestion(){
        Random rand = new Random();
        int questionsNum = loadQuestions().size();
        ArrayList<Integer> questionsNums = new ArrayList<Integer>();
        for (int i=0;i<questionsNum;i++){
            questionsNums.add(i);
        }        
        int randIndex = rand.nextInt(questionsNums.size());
        question = questionsNums.get(randIndex);
        questionsNums.remove(randIndex);
        return (question);
        
    }
    
    public static void main(String[] args) {
        StartScreen start = new StartScreen();
        start.setVisible(true);
        ChallengeScreen challenge = new ChallengeScreen ();
        WinScreen win = new WinScreen();
        LoseScreen lose = new LoseScreen();
    }
}
